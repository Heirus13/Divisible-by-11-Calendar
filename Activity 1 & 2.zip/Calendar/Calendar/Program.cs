﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Calendar
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter year: ");
            int year = int.Parse(Console.ReadLine());

            // Loop over each month
            for (int month = 1; month <= 12; month++)
            {
                Console.WriteLine();
                // Print month name
                Console.WriteLine(GetMonthName(month));

                // Print day headers
                Console.WriteLine("  Sun Mon Tue Wed Thu Fri Sat");

                // Get the number of days in the month
                int daysInMonth = DateTime.DaysInMonth(year, month);

                // Get the first day of the month
                DateTime firstDayOfMonth = new DateTime(year, month, 1);

                // Print the first week, accounting for the day of the week
                int currentDayOfWeek = (int)firstDayOfMonth.DayOfWeek;
                for (int i = 0; i < currentDayOfWeek; i++)
                {
                    Console.Write("    ");
                }
                for (int day = 1; day <= 7 - currentDayOfWeek; day++)
                {
                    Console.Write("{0,4}", day);
                }
                Console.WriteLine();

                // Print the rest of the weeks
                for (int day = 8 - currentDayOfWeek; day <= daysInMonth; day += 7)
                {
                    for (int i = 0; i < 7 && day + i <= daysInMonth; i++)
                    {
                        Console.Write("{0,4}", day + i);
                    }
                    Console.WriteLine();
                }
            }

            Console.ReadLine();
        }

        // Returns the name of the month for the given month number
        static string GetMonthName(int month)
        {
            switch (month)
            {
                case 1: return "            January";
                case 2: return "            February";
                case 3: return "            March";
                case 4: return "            April";
                case 5: return "            May";
                case 6: return "            June";
                case 7: return "            July";
                case 8: return "            August";
                case 9: return "            September";
                case 10: return "            October";
                case 11: return "            November";
                case 12: return "            December";
                default: return "";
            }
        }
    }
}

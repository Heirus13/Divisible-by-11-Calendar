﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Divisibleby11
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a integer: ");
            string input = Console.ReadLine();
            int n = int.Parse(input);
            int t = CalculateT(n);

            if (t % 11 == 0)
            {
                Console.WriteLine(n + " is divisible by 11.");
            }
            else
            {
                Console.WriteLine(n + " is not divisible by 11.");
            }
        }

        static int CalculateT(int n)
        {
            int t = 0;
            int sign = 1;

            while (n > 0)
            {
                int digit = n % 10;
                t += sign * digit;
                sign *= -1;
                n /= 10;
            }

            return t;
        }
    }
}
